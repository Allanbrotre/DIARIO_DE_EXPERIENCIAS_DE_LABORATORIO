﻿using System;

public class Class1
{
		static void Main(string[]args) {

		Console.WriteLine("Ingrese su nombre");
		string Nombre = Conslole.ReadLine();

			Console.WriteLine("Hola mundo");
			Console.WriteLine("Soy"+ Nombre );
			
		/* comentario */
			Console.Write("Hola mundo");
			Console.Write("Soy "+ Nombre);
			Console.ReadKey();
		
		}	
}
