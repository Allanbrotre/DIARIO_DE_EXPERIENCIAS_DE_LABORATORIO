﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L4_AJCL_1209023
{
    internal class Program
    {
        static void Main(string[] args)
        {            
           
            Console.WriteLine("Ingrese valor 1");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese valor 2");
            int xx = Convert.ToInt32(Console.ReadLine());

            /* operaciones aritméticas */
            Console.WriteLine(x+" + "+xx+" = "+(x+xx));
            Console.WriteLine(x + " - " + xx + " = " + (x-xx));
            Console.WriteLine(x + " * " + xx + " = " + (x*xx));
            Console.WriteLine(x + " / " + xx + " = " + (double)x/xx);

            Console.WriteLine(x + " DIV " + xx + " = " + x / xx);
            Console.WriteLine(x + " MOD " + xx + " = " +x %xx);
            /* operacion con boleana */
            if (x>xx)
            {
                Console.WriteLine("Es mayor el valor n1");
            }
            if (x< xx)
            {
                Console.WriteLine("Es mayor el valor n2");
            }
            if (x == xx)
            {
                Console.WriteLine("Los dos valores son iguales");
            }
            Console.ReadKey();

        }
    }
}
