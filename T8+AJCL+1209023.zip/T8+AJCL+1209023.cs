﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace T8_AJCL_1209023
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Char sig = ' ';
            int a = 0;
            int x = 0;
            int y = 0;
            int suma = 0;
            Console.WriteLine("Inngrese una de las opciones en mayusculas");
            sig = Convert.ToChar(Console.ReadLine());

            if (sig =='A' || sig == 'B' || sig == 'C' ) {
                switch (sig)
                {
                   
                    case'A':
                        Console.WriteLine("Ingres un valor");
                        x = Convert.ToInt32(Console.ReadLine());
                        do
                        {
                            y++;
                            suma = suma + y;           
                            
                        }while (y<x);
                        break;

                    case 'B':
                        Console.WriteLine("Ingres un valor");
                        x = Convert.ToInt32(Console.ReadLine());
                        int mul = 0;
                        for (int p = 0; p <=10; p++)
                        {
                            mul = x * p;
                            Console.WriteLine(x +" * "+p+" = "+mul);
                        }

                        break;

                    case 'C':
                        Console.WriteLine("Ingres un valor");
                        x = Convert.ToInt32(Console.ReadLine());
                        int su = 0;
                        int div = x;
                        if (x>0)
                        {
                            Console.Write(x + " =");
                            do
                            {
                                su++;
                                div = x % su;
                                if(div==0 && !(su==x))
                                {
                                    Console.Write(su+ ", ");
                                }

                                
                            } while (su<x);
                        }
                        else
                        {
                            Console.WriteLine("Ingreso un valor incorrecto");
                        }
                        break;
                }
            }
            else
            {
                Console.WriteLine("Ingreso un valor que no pertenece al ménu");
            }
            Console.ReadKey();
        }
    }
}
